import UIKit

var greeting = "Hello, playground"
print("hii",10,12.25)//comma seperated gives a space in outout

// string interpolation(\varName)
var name = "Sanjay"
var grade = 89.92
print("Hello, \(name)! Your grade is \(grade)")

var programmingLanguage = "swift"
print("I like the \(programmingLanguage) programming language")
 var age = 23
print("You are \(age) years old and in another \(age) years, you will be \(age * 2)")
print("""
Hello
World!
ugwsuyqw
kgsuyqw
""")
// \r carriage return
print ("Hello All,\rWelcome to Swift programming")
let  welcomeMessage : String = "Hello!"
   print(welcomeMessage , "All")
   
print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : ":-" )
print("Spring 2022")
print("The list of numbers are ",terminator: "--")
print(1,2,3,4,5,6)
print("The new pattern is",terminator: "---")
print(1,2,3,4,5,6, separator: "-")


let pi = 3.14
//pi = 5.34 //change 'let' to 'var' to make it mutable
// let pi = 3.14
print(pi)

var mobileBrand = "Apple"
mobileBrand = "Samsung"
print(mobileBrand)

var Age : Int = 23
Age = Age * 2
print(Age)

var aweMessage = "This is Superb!"
print(aweMessage)
print("aweMessage")

var course1 = "iOS"
var course2 = "Java"
print(course1,course2)
print(course1,"-",course2)

print(10,20,30)
print(12.3,23.4)

var httpError = (errorCode : 404 , errorMessage : "Page Not Found")
print(httpError)
print(httpError.errorCode,terminator: ":")
print(httpError.errorMessage)
//print(httpError.errorCode+httpError.errorMessage)note: overloads for '+' exist with these partially matching parameter lists: (Int, Int), (String, String)


var name1 = ("sanjay","Varun")
var fName = name1.0
var lName = name1.1
print(fName , terminator: ",")
print(lName)

var origin = (x : 0 , y : 0)
var point = origin
print(point)

let city = (name2 : "Maryville" , pop : "11,000")
let (cityName ,cityPop) = (city.0 , city.1)
print(cityName)
print(cityPop)

let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

var fname = "Joe"
var lname = "Root"
(fname , lname) = (lname , fname)
print("First Name is \(fname) and Last Name is \(lname)")

var cricketKit = ("handGloves" ,"helmet",("bat","ball"))//index 2 having two defferent items
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
